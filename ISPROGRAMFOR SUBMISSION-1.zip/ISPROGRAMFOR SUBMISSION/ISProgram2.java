import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class ISProgram2 {
	static int n, steps = 0, restarts = 0; // variables for queens,steps and restarts
	static int[] config; // store current state

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		// Obtain input from user
		System.out.println("Enter the value of n");
		n = s.nextInt();
		config = new int[n];
		Random r = new Random();
		// Generate random initial state
		for (int i = 0; i < n; i++) {
			config[i] = r.nextInt(n);
		}
		// Hill climbing with random restart
		randomRestartHillClimbing(config);
	}

	private static int checkHeuristic(int[] input) {
		// check heuristic of current configuration
		int h = 0;
		for (int i = 0; i < n; i++) {
			for (int j = i + 1; j < n; j++) {
				if ((Math.abs(i - j) == Math.abs(input[i] - input[j])) || input[i] == input[j]) {
					h++;
				}
			}
		}
		return h;
	}

	public static void randomRestartHillClimbing(int[] input) {
		int newh = checkHeuristic(input);
		// heuristic zero means solution found
		if (newh == 0) {
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					if (input[i] == j) {
						// Print 1 if it is a queen
						System.out.print("1 ");
					} else {
						System.out.print("0 ");
					}
				}
				System.out.println("");
			}
			System.out.println("Steps taken by program to reach solution = " + steps + "\n"
					+ "Restarts required by the program = " + restarts + "\nMaximum n program works for = 30");

			System.exit(1);
		} else {
			next(input, newh);
		}
	}

	public static void next(int[] input, int newh) {
		// make next move
		int k = -1;
		int l = -1;
		int oldh = newh;
		for (int i = 0; i < n; i++) {
			int oldj = input[i];
			for (int j = 0; j < n; j++) {
				if (oldj != j) {
					input[i] = j;
					int temph = checkHeuristic(input);
					if (temph < oldh) {
						k = i;
						oldh = temph;
						l = j;

					}
				}
			}
			input[i] = oldj;
		}

		if (k != -1 && l != -1) {
			input[k] = l;
			steps++;
			randomRestartHillClimbing(input);

		} else {
			// Random restart
			Random r = new Random();
			for (int i = 0; i < n; i++) {
				config[i] = r.nextInt(n);
			}
			restarts++;
			randomRestartHillClimbing(config);
		}
	}
}
