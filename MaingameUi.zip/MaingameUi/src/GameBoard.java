
import java.io.*;
import java.util.*;
import java.util.ArrayList;

public class GameBoard {
  

    List<Placeidentifier> checkfreespacers;
    int[][] Tictactoeboard;      //array used to store the states
    Scanner scan = new Scanner(System.in); // scanner for taking input from the user
    

    void fixstate(int a[][])    
    {                           //Function used to set the state of the board
        this.Tictactoeboard = a;
    } 

    List<calculatescore> explored = new ArrayList<>();
     private int Boardevaluator(int X, int O){   //Heuristic function to eval;uate the board
        int temp;

       
         if(X==0)
            temp = -(10*O);
        
         else if(O==0)
            temp = 10*X;
        
         else
            temp=0;
        return temp;
    }

    public int calculateBoard() {    //checking for x and o throughout the table
        int score = 0;

        for (int i = 0; i < Tictactoeboard.length; i++) {    //Checking rows of the game board
            int blank = 0;
            int X = 0;//variable for player human
            int O = 0; // variable for player computer
            for (int j = 0; j < Tictactoeboard.length; j++) {
                if (Tictactoeboard[i][j] == 1) 
                    X=X+1;
                 else if (Tictactoeboard[i][j] == 0) 
                   blank=blank+1;
                 else 
                    O=O+1;
       } 
            score=score+Boardevaluator(X, O); 
        }

        for (int j = 0; j < Tictactoeboard.length; ++j) {    //Checking columns
            int empty_blanks = 0;
            int X = 0;
            int O = 0;
            for (int i = 0; i < Tictactoeboard.length; ++i) {
                if (Tictactoeboard[i][j] == 0) {
                    empty_blanks=empty_blanks+1;
                } else if (Tictactoeboard[i][j] == 1) {
                    X=X+1;
                } else {
                    O=O+1;
                } 
            }
            score=score+Boardevaluator(X, O);
        }

        int empties = 0;
        int Player_X = 0;
        int Player_O = 0;

        for (int i = 0, j = 0; i < Tictactoeboard.length; i++, j++) {    //Checking diagonal
            if (Tictactoeboard[i][j] == 1) {
                Player_X=Player_X+1;
            } else if (Tictactoeboard[i][j] == 2) {
                Player_O=Player_O+1;
            } else {
                empties=empties+1;
            }
        }

        score=score+Boardevaluator(Player_X, Player_O);

        empties = 0;
        Player_X = 0;
        Player_O = 0;

        for (int i = Tictactoeboard.length-1, j = 0; i >= 0; --i, ++j) {     //Checking diagonal
            
             if (Tictactoeboard[i][j] == 2) {
                Player_O=Player_O+1;
            } 
               else if (Tictactoeboard[i][j] == 1) 
                Player_X=Player_X+1;
                 else 
                empties=empties+1;
            
        }

        score=score+Boardevaluator(Player_X, Player_O);

        return score;
    }


  public void chooseamove(Placeidentifier place, int player) {

        Tictactoeboard[place.good_x_position][place.good_y_position] = player;
    }

    public Placeidentifier next_Best_Move() {
        //Fucntion used to return the best move possible 
        int MAX_VALUE = -100000;
        int BEST_VALUE = -1;

        for (int i = 0; i < explored.size(); ++i) {
            if (MAX_VALUE < explored.get(i).score) {
                MAX_VALUE = explored.get(i).score;
                BEST_VALUE = i;
            }
        }
        return explored.get(BEST_VALUE).place;
    }

    
   
     public boolean GameOver() {
        //Game is over is someone has won, or board is full (draw)
        
        boolean p=(X_player_won() || O_player_won() || remainingmoves().isEmpty());
        return p;
    }
    
    
    public int Minmaxtree_with_pruning(int alpha, int beta, int depth, int turn){
        //Function to implement the Minimax Algorithm with Alpha Beta pruning
        int pruning_depth;
        if (Tictactoeboard.length==3)
            pruning_depth=-1;// setting the pruning depth since for 3*3 tictactoe
        else
            pruning_depth=4;// setting for hoigher order tictac toe
        
        if(beta<alpha){ 

            if(turn == 1) 
                return Integer.MAX_VALUE; 
            else 
                return Integer.MIN_VALUE; 
        }
        else if (beta==alpha){ 

            if(turn == 1) 
                return Integer.MAX_VALUE; 
            else 
                return Integer.MIN_VALUE; 
        }
        
        if(depth == pruning_depth || GameOver()) 
            return calculateBoard();
        
        List<Placeidentifier> freeMoves = remainingmoves();
        
        if(freeMoves.isEmpty()) return 0;
        
        if(depth==0) explored.clear(); 
        
        int maximum_val = Integer.MIN_VALUE, minimum_val = Integer.MAX_VALUE;
        
        for(int i=0;i<freeMoves.size(); ++i){
            Placeidentifier place = freeMoves.get(i);
            
            int curr_score = 0;
            
            if(turn == 1){
                chooseamove(place, 1); 
                curr_score = Minmaxtree_with_pruning(alpha, beta, depth+1, 2);
                maximum_val = Math.max(maximum_val, curr_score); 
                
                alpha = Math.max(curr_score, alpha);  //Set the value of alpha
                
                if(depth == 0)
                    explored.add(new calculatescore(curr_score, place));
            }
            else if(turn == 2){
                chooseamove(place, 2);
                curr_score = Minmaxtree_with_pruning(alpha, beta, depth+1, 1); 
                minimum_val = Math.min(minimum_val, curr_score);
                
                beta = Math.min(curr_score, beta);    //Set the value of beta using math minimum function
            }
            Tictactoeboard[place.good_x_position][place.good_y_position] = 0;
            
            if(curr_score == Integer.MAX_VALUE || curr_score == Integer.MIN_VALUE) 
                break;  //If a pruning has been done, we don't evaluate the rest of the sibling states
        }
     
          if(turn==1)
              return maximum_val;
          
          else
              return minimum_val;
    }  

   

    public boolean X_player_won() {
        //Function to check if X has Won
        if (Tictactoeboard.length==3)
        {
            if ((Tictactoeboard[0][0] == Tictactoeboard[1][1] && Tictactoeboard[0][0] == Tictactoeboard[2][2] && Tictactoeboard[0][0] == 1) || (Tictactoeboard[0][2] == Tictactoeboard[1][1] && Tictactoeboard[0][2] == Tictactoeboard[2][0] && Tictactoeboard[0][2] == 1)) {
            //System.out.println("X Diagonal Win");
            return true;
        }
        for (int i = 0; i < 3; ++i) {
            if (((Tictactoeboard[i][0] == Tictactoeboard[i][1] && Tictactoeboard[i][0] == Tictactoeboard[i][2] && Tictactoeboard[i][0] == 1)
                    || (Tictactoeboard[0][i] == Tictactoeboard[1][i] && Tictactoeboard[0][i] == Tictactoeboard[2][i] && Tictactoeboard[0][i] == 1))) {
                // System.out.println("X Row or Column win");
                return true;
            }
        }
        return false;
        }
        else
        {
        int diag=0;
        int row,column;
        for (int i= 0, j = 0; i < Tictactoeboard.length; ++i, ++j) {
            if (Tictactoeboard[i][j] == 1)
            {
                diag=diag+1;
            }
        }
        if (diag==Tictactoeboard.length)
            return true;

        diag=0;

        for (int i = Tictactoeboard.length-1, j = 0; i >=0; --i, ++j) {
            if (Tictactoeboard[i][j] == 1)
                diag=diag+1;
        }
        if (diag==Tictactoeboard.length)
            return true;
        
        for (int i=0; i<Tictactoeboard.length; i++)
        {   
            row=0;
            for (int j=0; j<Tictactoeboard.length; j++)
            {
                if (Tictactoeboard[i][j]==1)
                    row++;
            }
            if (row==Tictactoeboard.length)
                return true;
        }
        for (int i=0; i<Tictactoeboard.length; i++)
        {   
            column=0;
            for (int j=0; j<Tictactoeboard.length; j++)
            {
                if(Tictactoeboard[j][i]==1)
                    column++;
            }
            if (column==Tictactoeboard.length)
                return true;
        }
        return false;
    }
    }
     public List<Placeidentifier> remainingmoves() {
        //This function is used to get all the available states and store them in an arraylist
        checkfreespacers = new ArrayList<>();
        for (int i = 0; i < Tictactoeboard.length; ++i) {
            for (int j = 0; j < Tictactoeboard.length; ++j) {
                if (Tictactoeboard[i][j] == 0) {
                    checkfreespacers.add(new Placeidentifier(i, j));
                }
            }
        }
        return checkfreespacers;
    }

    public boolean O_player_won() {
        //Function to check if O has won
        //created a function owon to check whether the computer won the game by exploring all  the possible scenarios 
        if (Tictactoeboard.length==3)
        {
            if ((Tictactoeboard[0][0] == Tictactoeboard[1][1] && Tictactoeboard[0][0] == Tictactoeboard[2][2] && Tictactoeboard[0][0] == 2) || (Tictactoeboard[0][2] == Tictactoeboard[1][1] && Tictactoeboard[0][2] == Tictactoeboard[2][0] && Tictactoeboard[0][2] == 2)) {
            // System.out.println("O Diagonal Win");
            return true;
        }
        for (int i = 0; i < 3; ++i) {
            if ((Tictactoeboard[i][0] == Tictactoeboard[i][1] && Tictactoeboard[i][0] == Tictactoeboard[i][2] && Tictactoeboard[i][0] == 2)
                    || (Tictactoeboard[0][i] == Tictactoeboard[1][i] && Tictactoeboard[0][i] == Tictactoeboard[2][i] && Tictactoeboard[0][i] == 2)) {
                //  System.out.println("O Row or Column win");
                return true;
            }// for 3*3 no need 
        }

        return false;
        }
        else
        {
        int Diagonals=0;

        for (int i = 0, j = 0; i < Tictactoeboard.length; ++i, ++j) {
            if (Tictactoeboard[i][j] == 2)
            {
                Diagonals=Diagonals+1;
            }
        }
        if (Diagonals==Tictactoeboard.length)
            return true;

        Diagonals=0;

        for (int i = Tictactoeboard.length-1, j = 0; i >=0; --i, ++j) {
            if (Tictactoeboard[i][j] == 2)
                Diagonals=Diagonals+1;
        }
        if (Diagonals==Tictactoeboard.length)
            return true;

        int row_orbit,column_orbit;
        for (int i=0; i<Tictactoeboard.length; i++)
        {   
            row_orbit=0;
            for (int j=0; j<Tictactoeboard.length; j++)
            {
                if (Tictactoeboard[i][j]==1)
                    row_orbit=row_orbit+1;
            }
            if (row_orbit==Tictactoeboard.length)
                return true;
        }
        for (int i=0; i<Tictactoeboard.length; i++)
        {   
            column_orbit=0;
            for (int j=0; j<Tictactoeboard.length; j++)
            {
                if(Tictactoeboard[j][i]==1)
                    column_orbit=column_orbit+1;
            }
            if (column_orbit==Tictactoeboard.length) // if column has equal to the number of columns or the number of rows
                return true;
        }
        return false;
    }
    }

   
}

    
    
    

