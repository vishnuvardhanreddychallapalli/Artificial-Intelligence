


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class MaingameUi extends JFrame {

	
	
        int x_position, y_position;
	int player_turn;
	GameBoard Gameboard;
	Random Randomizerrr;
	Placeidentifier perfect;
	JComboBox tictactoe_board_size;
	int boardsize = 3;
	int counter = 0;
	JButton optionofrestart;
        JButton result;
	JPanel player;
	JPanel paneller;
        JLabel select_turn;
	JLabel select_size;
	String[] giveturn;
	JComboBox gameturner;
	JPanel playbuttons;
	JButton[][] Tictactoeboardarray;
        JLabel groundspacer;
        

	MaingameUi() {
		
		Gameboard = new GameBoard();// creates new board
		Randomizerrr = new Random(); // creates an object for the Random class for selecting random position when computer choose the turn first
		playbuttons = new JPanel(); //buttons object
                optionofrestart = new JButton("Play-again/Reset");// creating button
                select_turn = new JLabel("Select who starts first");
                result=new JButton("Result");
		playbuttons.setLocation(500, 500);
                System.out.println("welcome game");
	        groundspacer = new JLabel(" ");
		String[] turnprovider = { "select","Human", "Computer" };// to display the text on button
		String[] boardbuttonsize = {"Select", "3", "5", "7","9"};
		gameturner = new JComboBox(turnprovider);
		tictactoe_board_size = new JComboBox(boardbuttonsize);
               
        

		setResizable(false);// this function disallow the screen to maximize
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		select_size = new JLabel("Select board size");
		
		paneller = new JPanel();
		setLayout(new FlowLayout()) ;
                GridLayout gridder = new GridLayout() ;
                
                gridder.setRows(3);
                gridder.setColumns(3);
		paneller.setLayout(gridder);
                paneller.setLocation(100,100) ;
                paneller.setBounds(100,100,300,300) ;
		paneller.add(select_size) ;
		paneller.add(tictactoe_board_size);
		paneller.add(select_turn);
		paneller.add(gameturner);
		paneller.add(groundspacer);
                paneller.add(new JLabel("Tic Tac Toe")) ;
               //ombos.setbackground(red);
            // super("the mighty tictactoe game");
                getContentPane().setBackground(new java.awt.Color(0,0,0));


		add(paneller);
                
               //  c.setBackground(Color.red); 

		tictactoe_board_size.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {

				SwingUtilities.invokeLater(new Runnable() {
					@Override
					public void run() {
                                            String item = tictactoe_board_size.getSelectedItem()
								.toString() ;    
                                            
                                            if("Select".equalsIgnoreCase(item) || item == null) {
                                             
                                            return ;
                                            }else{    
						boardsize = Integer.parseInt(item);
						
                                                System.out.println();
                                                Tictactoeboardarray = new JButton[boardsize][boardsize];
						GridLayout gl = new GridLayout(boardsize, boardsize);
                                                Gameboard.fixstate(new int[boardsize][boardsize]);
					         playbuttons.setLayout(gl);
						playbuttons.setVisible(true);
                                                playbuttons.setLocation(100, 100);
						add(playbuttons);
						
						for (int i = 0; i < boardsize; i++) {
							for (int j = 0; j < boardsize; j++) {
								Tictactoeboardarray[i][j] = new JButton("-");
                                                                Tictactoeboardarray[i][j].setBackground(Color.white);// setthe white background for tictac board
								//boardArray[i][j].setLocation(500+(i*boardArray[i][j].getWidth()), 500+(j*boardArray[i][j].getHeight()));
                                                                playbuttons.add(Tictactoeboardarray[i][j]);
                                                                 
								final int x_intializer = i;
								final int y_initializer = j;
								Tictactoeboardarray[x_intializer][y_initializer]
										.addActionListener(new ActionListener() {
			                                         public void actionPerformed(
								     final ActionEvent actioneventer_object) {

									SwingUtilities
										.invokeLater(new Runnable() {
											@Override
											public void run() {

											if (actioneventer_object.getSource() == Tictactoeboardarray[x_intializer][y_initializer])
																	
											{
											Tictactoeboardarray[x_intializer][y_initializer].setEnabled(false);
										        x_position = x_intializer;
										        y_position = y_initializer;
										        Tictactoeboardarray[x_intializer][y_initializer].setText("O");
										        counter++;

										    int count = 1;
					                                         while (!Gameboard.GameOver()&& count == 1) {
												Placeidentifier userMove = new Placeidentifier(x_intializer,y_initializer);
											

									            Gameboard.chooseamove(userMove,2);
										      if (Gameboard.GameOver())
										      break;
										  Gameboard.Minmaxtree_with_pruning(Integer.MIN_VALUE,Integer.MAX_VALUE,0,1);
																				
									          perfect = Gameboard.next_Best_Move();
									          Gameboard.chooseamove(perfect,1);
                                                                                  Tictactoeboardarray[perfect.good_x_position][perfect.good_y_position].setText("X");
                                                                                  Tictactoeboardarray[perfect.good_x_position][perfect.good_y_position].setEnabled(false);
                                                                                  counter++;
                                                                                  count++;
                                                                                 }
                                                                               }
																				// and
								 if(boardsize*boardsize==counter 	|| (Gameboard.X_player_won())											// O
																					// is
																					// the
																					// user
																					// for
																					// O
																					// and
																					// O
																					// is
																					// the
																					// user
														                                
								
																|| (Gameboard.O_player_won())) {
																	if (Gameboard.X_player_won()) {
																		String xwon = "You Lost  Game.";
																		groundspacer.setText(xwon);
                                                                                                                                              //  groundspacer.setEnabled(false);
                                                                                                                                                
                                                                                                                                          //      boardArray[p.x][p.y].setEnabled(false);
                                                                                                                                                
                                                                                                                                               
																	} else if (Gameboard
																			.O_player_won()) {
																		String owon = "You Won Game.";
																		groundspacer.setText(owon);
                                                                                                                                                //   groundspacer.setEnabled(false);
                                                                                                                                               //    boardArray[p.x][p.y].setEnabled(false);
                                                                                                                                                
																	} else {
																		String draw = "Draw";
																		groundspacer.setText(draw);
                                                                                                                                               // groundspacer.setEnabled(false);
                                                                                                                                               // boardArray[p.x][p.y].setEnabled(false);
                                                                                                                                             

																	}
																}
															}
														});
											}
										});
								validate();
								repaint();
							}
						}

						tictactoe_board_size.setEnabled(false);
                                        }
					}
				});
			}
		});

		player = new JPanel();

		player.setLayout(new FlowLayout(FlowLayout.RIGHT));
		player.add(optionofrestart);
		add(player, BorderLayout.SOUTH);

		optionofrestart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {

				SwingUtilities.invokeLater(new Runnable() {
					@Override
					public void run() {
						dispose();
						new MaingameUi();

					}
				});
			}
		});

		gameturner.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {

				SwingUtilities.invokeLater(new Runnable() {
					@Override
					public void run() {
						if (gameturner.getSelectedItem().toString().equalsIgnoreCase("Human")) {
							groundspacer.setText("User goes first");
							player_turn = 1;
						} else {
							groundspacer.setText("Computer goes first");
							player_turn = 2;
							Placeidentifier p = new Placeidentifier(Randomizerrr.nextInt(boardsize), Randomizerrr
									.nextInt(boardsize));
							Gameboard.chooseamove(p, 1);
							Tictactoeboardarray[p.good_x_position][p.good_y_position].setText("X");
							Tictactoeboardarray[p.good_x_position][p.good_y_position].setEnabled(false);
							counter=counter+1;

						}

						gameturner.setEnabled(false);
					}
				});
			}
		});

		setVisible(true);
		setSize(400, 500);
               
               setBackground(Color.red); 
	}

	public static void main(String[] args) throws Exception {
		MaingameUi g = new MaingameUi();
	}
}

   


