/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



public class Placeidentifier {
    
    
    int good_x_position, good_y_position;

    public Placeidentifier(int x, int y) {
        this.good_x_position = x;
        this.good_y_position = y;
    }
    
}
