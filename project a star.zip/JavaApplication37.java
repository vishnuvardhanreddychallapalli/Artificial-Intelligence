/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaApplication37;

/**
 *
 * @author vishn
 */

import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.TreeSet;
public class JavaApplication37 {

    public static int[] goal;
    public static int explored=0;
    public static TreeSet<String> notvisited;
   
    static int distance(int[] puzzle, int size) {
                                int i, dis = 0;
                                for (i=0; i<size*size ; i++) {
                                                for(int x =0;x<size*size;x++){
                                                    if((puzzle[i] - goal[x]) == 0){
                                                        int x1 = x/size;
                                                        int x2 = i/size;
                                                        int y1 = x%size;
                                                        int y2 = i%size;
                                                        dis = dis + Math.abs(x1 - x2) + Math.abs(y1 - y2);
                                                    }
                                                }
                                }
                                return dis;
                }
                
                static int[] movepuzzle(int[] puzzle, int size, int action) {
                                int i, x, y;
                                int [] tmp;
                                x = y = -1;
                                for (i=0; i <size*size; i++) {
                                                if (puzzle[i] == 0) {
                                                                x = i/size;
                                                                y = i%size;
                                                                break;
                                                }
                                }
                                
                                if (action == 0) {
                                                if (x > 0) {
                                                                tmp = new int[size * size];
                                                                for (i=0; i<size*size; i++) {
                                                                                tmp[i] = puzzle[i];
                                                                }
                                                                tmp[x*size + y] = tmp[(x-1)*size + y];
                                                                tmp[(x-1)*size + y] = 0;
                                                                return tmp;
                                                }
                                }
                                
                                if (action == 1) {
                                                if (y > 0) {
                                                                tmp = new int[size * size];
                                                                for (i=0; i<size*size; i++) {
                                                                                tmp[i] = puzzle[i];
                                                                }
                                                                tmp[x*size + y] = tmp[x*size + y - 1];
                                                                tmp[x*size + y - 1] = 0;
                                
                                                                return tmp;
                                                }
                                }
                                
                                if (action == 2) {
                                                if (y < size -1) {
                                                                tmp = new int[size * size];
                                                                for (i=0; i<size*size; i++) {
                                                                                tmp[i] = puzzle[i];
                                                                }
                                                                tmp[x*size + y] = tmp[(x)*size + y + 1];
                                                                tmp[x*size + y + 1] = 0;
                                                                return tmp;
                                                }
                                }
                                
                                if (action == 3) {
                                                if (x < size - 1) {
                                                                tmp = new int[size * size];
                                                                for (i=0; i<size*size; i++) {
                                                                                tmp[i] = puzzle[i];
                                                                }
                                                                tmp[x*size + y] = tmp[(x+1)*size + y];
                                                                tmp[(x+1)*size + y] = 0;
                                                                return tmp;
                                                }
                                }
                                return null;
                }
               
                        
                
                public static void solve(int[] puzzle, int size) {
                                class Node {
                                                int[] puzzle;
                                                int size;
                                                int cost;
                                                Node parent;
                                                int prevmv;
                                                String _string;
                                                void tostring() {
                                                                for (int i = 0; i <size*size; i++){
                                                                                if (this._string == null) {
                                                                                                this._string = Integer.toString(puzzle[i]);
                                                                                } else {
                                                                                                this._string += Integer.toString(puzzle[i]);
                                                                                }
                                                                }
                                                }
                                };

                                class NodeComparator2 implements Comparator<Node> {
                                                public int compare(Node e1, Node e2) {
                                                                return  (e1.cost - e2.cost) + distance(e1.puzzle, e1.size) - distance(e2.puzzle, e2.size);
                                                                
                                                                
                                                                
                                                }
                                };
                                
                                
                                
                                Node root = new Node();
                                root.puzzle = puzzle;
                                root.size = size;
                                root.prevmv = -1;
                                root.cost = 0;
                                root.tostring();
                                Node tmp, curr = root;
                                PriorityQueue<Node> qu = new PriorityQueue<Node>(1, new NodeComparator2());
                                notvisited = new TreeSet<String>();
                                notvisited.add(curr._string);
                                int [] tmpp;
                                
                                int dis = distance(curr.puzzle, curr.size); 
                                
                                while( dis != 0) {
                                                System.out.println();
                                                System.out.println("Exploring node");
                                                System.out.println("F(n):"+(curr.cost + dis));
                                                System.out.println();
                                                print2d(curr._string);
                                                explored++;
                                                // UP = 0, LEFT=1, RIGHT=2, BOTTOM=3
                                                for (int i=0; i<4; i++) {
                                                                tmpp = movepuzzle(curr.puzzle, curr.size, i);
                                                                if (tmpp != null) {
                                                                                tmp = new Node();
                                                                                tmp.puzzle = tmpp;
                                                                                tmp.size = size;
                                                                                tmp.parent = curr;
                                                                                tmp.prevmv = i;
                                                                                tmp.cost = curr.cost + 1;
                                                                                tmp.tostring();
                                                                                if (!notvisited.contains(tmp._string)) {
                                                                                             String abc=tmp._string;
                                                                                             qu.add(tmp);
                                                                                             notvisited.add(tmp._string);
                                                                                }
                                                                }
                                                }
                                                curr = qu.poll();
                                                
                                                dis = distance(curr.puzzle, curr.size);
                                }
                                
                }
                public static void print2d(String a)
                {
                    for(int i=0;i<a.length();i++)
                    {
                        if(i%3==0)
                            System.out.println();
                        System.out.print(a.substring(i,i+1)+" ");
                    }
                }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
                       System.out.println("Enter size");
                        int size = in.nextInt();
                        System.out.println("Enter Initial State");
                        int puzzle[] = new int[size*size];
                        goal= new int[size*size];
                        for (int i = 0; i < size * size; i++) {
                               puzzle[i] = in.nextInt();
                        }
                        System.out.println("Enter goal State");
                        for (int i = 0; i < size * size; i++) {
                            goal[i] = in.nextInt();
                     }
                        solve(puzzle, size);
                        System.out.println();
                        System.out.println("Total number of explored nodes are "+explored);
                        System.out.println("Total number of nodes generated are "+notvisited.size());
    }
    }