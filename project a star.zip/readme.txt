please enter the size of matrix: 3
input: give 9 numbers sequentially from 0 t0 8
1 2 3 4 5 6 7 8 0
output: give nine numbers from 0 to 8
1 2 3 4 5 6 7 8 0.
Sample input and output1:
run:
Enter size
3
Enter Initial State
2 8 3 1 6 4 7 0 5
Enter goal State
1 2 3 8 6 4 7 5 0

Exploring node
F(n):6


2 8 3 
1 6 4 
7 0 5 
Exploring node
F(n):5


2 8 3 
1 6 4 
7 5 0 
Exploring node
F(n):8


2 8 3 
1 6 0 
7 5 4 
Exploring node
F(n):9


2 8 3 
1 0 4 
7 6 5 
Exploring node
F(n):9


2 8 3 
1 6 4 
0 7 5 
Exploring node
F(n):10


2 0 3 
1 8 4 
7 6 5 
Exploring node
F(n):10


2 8 3 
1 4 0 
7 6 5 
Exploring node
F(n):11


2 3 0 
1 8 4 
7 6 5 
Exploring node
F(n):11


2 8 3 
1 4 5 
7 6 0 
Exploring node
F(n):11


2 8 0 
1 6 3 
7 5 4 
Exploring node
F(n):11


2 8 3 
1 0 6 
7 5 4 
Exploring node
F(n):11


0 2 3 
1 8 4 
7 6 5 
Exploring node
F(n):10


1 2 3 
0 8 4 
7 6 5 
Exploring node
F(n):9


1 2 3 
8 0 4 
7 6 5 
Exploring node
F(n):8


1 2 3 
8 6 4 
7 0 5 
Total number of explored nodes are 15
Total number of nodes generated are 29
BUILD SUCCESSFUL (total time: 1 minute 51 seconds)


